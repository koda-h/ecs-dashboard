(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__06.-pfn._.css","static/chunks/node_modules_0_a0xga._.js","static/chunks/components_ui_sonner_tsx_122lofw._.js"],
    source: "dynamic"
});
